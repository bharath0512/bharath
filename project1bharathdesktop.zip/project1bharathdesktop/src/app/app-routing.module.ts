import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';

import { HomeComponent } from './home/home.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { RegistrationComponent } from './registration/registration.component';
import { AdminComponent } from './admin/admin.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { StockComponent } from './stock/stock.component';
import { CompanyComponent } from './company/company.component';
import { SalesComponent } from './sales/sales.component';
import { OrdersComponent } from './orders/orders.component';


const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot([{path:'home',component:HomeComponent,
                            children:[{path:'login',component:LoginComponent},
                             {path:'registration',component:RegistrationComponent},
                             {path:'aboutus',component:AboutusComponent},
                             {path:'k',redirectTo:'/home',pathMatch:'full'}],},
                            
                        { path:'admin',component:AdminComponent,
                   children:[{path:'stock',component:StockComponent},
                   {path:'company',component:CompanyComponent},
                   {path:'sales',component:SalesComponent},{path:'orders',component:OrdersComponent}] ,}, 
                        {path:'',redirectTo:'/home',pathMatch:'full'},    
                        {path:'**', component:PagenotfoundComponent},
                       ]
                          
                          
                          
                          )],
  exports: [RouterModule]
})
export class AppRoutingModule { }
