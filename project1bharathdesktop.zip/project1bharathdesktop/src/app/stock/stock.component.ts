import { Component, OnInit } from '@angular/core';
import { DatatransferService } from '../datatransfer.service';

@Component({
  selector: 'app-stock',
  templateUrl: './stock.component.html',
  styleUrls: ['./stock.component.css']
})
export class StockComponent  {
  datast:any[]=[];
  constructor(private t:DatatransferService) 
  {
    this.t.getdatast().subscribe(x=>this.datast=x)
    console.log(this.datast);
   }
  

 
}
