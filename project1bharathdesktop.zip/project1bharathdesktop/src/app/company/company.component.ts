import { Component, OnInit } from '@angular/core';
import{DatatransferService}from'../datatransfer.service';
@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
datac:any[]=[];
  constructor(private c:DatatransferService) {
    this.c.getdatac().subscribe(y=>this.datac=y)
    console.log(this.datac);
   }

  ngOnInit() {
  }

}




