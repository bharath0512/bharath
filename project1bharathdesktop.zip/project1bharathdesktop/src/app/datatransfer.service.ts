import { Injectable } from '@angular/core';
import{HttpClient}from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DatatransferService {
  
  
  constructor(private http:HttpClient) { }
  
  
   
getdatast():Observable<any>
{
  return this.http.get('/assets/stock.json');
}
getdatac():Observable<any>
{
return this.http.get('/assets/company.json');
}

getdatas():Observable<any>
{
  return this.http.get('/assets/sales.json')
}


}
