import { Component, OnInit } from '@angular/core';
import{DatatransferService}from'../datatransfer.service';
@Component({
  selector: 'app-sales',
  templateUrl: './sales.component.html',
  styleUrls: ['./sales.component.css']
})
export class SalesComponent implements OnInit {
datas:any[]=[];
  constructor(private s:DatatransferService) { 
    this.s.getdatas().subscribe(z=>this.datas=z)
    console.log(this.datas);
  }

  ngOnInit() {
  }

}



